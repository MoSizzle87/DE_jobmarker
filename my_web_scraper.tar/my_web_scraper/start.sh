#!/bin/bash

# Export PATH to ensure it includes necessary directories
export PATH=/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin

# Log the start time
echo "Script started at $(date)" >> /home/admin/my_web_scraper/debug.log

# Change to the directory where the script is located
cd /home/admin/my_web_scraper

# Log the current directory
echo "Current directory: $(pwd)" >> /home/admin/my_web_scraper/debug.log

# Build the Docker images
/usr/local/bin/docker-compose build

# Log after building Docker images
echo "Docker images built at $(date)" >> /home/admin/my_web_scraper/debug.log

# Run the Docker Compose to execute the tests
/usr/local/bin/docker-compose run scraper python scraper.py
/usr/local/bin/docker-compose run scraper python remove_duplicates.py
/usr/local/bin/docker-compose run scraper python skills.py
/usr/local/bin/docker-compose run scraper python job_title.py

# Log the end time
echo "Script ended at $(date)" >> /home/admin/my_web_scraper/debug.log
